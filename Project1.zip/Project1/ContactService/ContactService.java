package contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
	
	//stores contact using contact ID as key
	private Map<String, Contact> contacts;
	
	//constructor initializing hashmap
	public ContactService() {
		contacts = new HashMap<String, Contact>();
		
	}
	//adds new contact to map
	public void addContact(Contact contact) {
		String id = contact.getContactID();
		//checks if id exists
		if (contacts.containsKey(id)) {
			throw new IllegalArgumentException("Contact Id already exists");
		}
		contacts.put(id, contact);
	}
	//deletes contact
	public void deleteContact(String contactId) {
		if (contacts.containsKey(contactId)) {
			contacts.remove(contactId);
			
		}
		else {
			throw new IllegalArgumentException("Contact Id not found");
		}
	}
	//updates first name
	public void updateFirstName(String contactId, String firstName) {
		if (contacts.containsKey(contactId)) {
			Contact contact = contacts.get(contactId);
			contact.setFirstName(firstName);
		}
		else {
			throw new IllegalArgumentException("Contact Id not found");
		}
	}
	//updates last name
	public void updateLastName(String contactId, String lastName) {
		if (contacts.containsKey(contactId)) {
			Contact contact = contacts.get(contactId);
			contact.setLastName(lastName);
		}
		else {
			throw new IllegalArgumentException("Contact Id not found");
		}
	}
	//updates phone number
	public void updatePhoneNumber(String contactId, String phoneNumber) {
		if (contacts.containsKey(contactId)) {
			Contact contact = contacts.get(contactId);
			contact.setPhoneNumber(phoneNumber);
		}
		else {
			throw new IllegalArgumentException("Contact Id not found");
		}
	}
	//updates address
	public void updateAddress(String contactId, String address) {
		if (contacts.containsKey(contactId)) {
			Contact contact = contacts.get(contactId);
			contact.setAddress(address);
		}
		else {
			throw new IllegalArgumentException("Contact Id not found");
		}
	}
	//returns contact object
	public Contact getContact (String contactId) {
		if (contacts.containsKey(contactId)) {
			return contacts.get(contactId);
		}
		else {
			return null;
		}
	}

}
