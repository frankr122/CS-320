package contact;

public class Contact {
	
	//contactID is unable to be changed once set
	private final String contactID;
	
	//updatable contact fields
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	//checks if phone number is only digits
	public boolean onlyDigits(String phone){
		for (int i = 0; i < phone.length(); i++) {
			if(!Character.isDigit(phone.charAt(i))) {
				return false;
			}
		}
		return true;
	}
	//Contact constructor
	public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		
		
		//validates contact id is under 10 digits
		if (contactID == null || contactID.length() > 10) {
			throw new IllegalArgumentException("Invalid Contact ID");
		}
		//validates first name (not null and under 10 digits)
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		//validates last name (not null and under 10 digits)
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		//validates phone number (not null, is equal to 10 digits long, and only contains digits)
		if (phoneNumber == null || phoneNumber.length() != 10 || !onlyDigits(phoneNumber)) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		//validates address (not null and less than 30 characters long)
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address");
		}
		//value assignment after passing validation
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
		
		//returns contactid
		public String getContactID() {
			return contactID;
		}
		//returns first name
		public String getFirstName() {
			return firstName;
		}
		//returns last name 
		public String getLastName() {
			return lastName;
		}
		//returns phone number
		public String getPhoneNumber() {
			return phoneNumber;
		}
		//returns address
		public String getAddress() {
			return address;
		}
		//sets first name after validation 
		public void setFirstName(String firstName) {
			if (firstName == null || firstName.length() > 10) {
				throw new IllegalArgumentException("Invalid First Name");
			}
			this.firstName = firstName;
		}
		//sets last name after validation 
		public void setlastName(String lastName) {
			if (lastName == null || lastName.length() > 10) {
				throw new IllegalArgumentException("Invalid Last Name");
			}
			this.lastName = lastName;
		}
		//sets phone number after validation 
		public void setPhoneNumber(String phoneNumber) {
			if (phoneNumber == null || phoneNumber.length() != 10 || !onlyDigits(phoneNumber)) {
				throw new IllegalArgumentException("Invalid phone number");
			}
			this.phoneNumber = phoneNumber;
			
		}
		//sets address after validation 
		public void setAddress(String Address) {
			if (address == null || address.length() > 30) {
				throw new IllegalArgumentException("Invalid address");
			}
			this.address = address;
		}
		
		
	}

}
