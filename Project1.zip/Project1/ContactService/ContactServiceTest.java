package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

	
	@Test
	//tests if contact can be added successfully
	void testAddContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact("1", "Joe", "Bob", "7898675309", "369 Test Street");
		
		service.addContact(contact);
		
		Contact result = service.getContact("1");
		assertEquals("Joe", result.getFirstName);
		
	}
	
	@Test
	//tests if duplicate contacts are rejected
	void testDuplicates() {
        ContactService service = new ContactService();
		
		Contact contact1 = new Contact("1", "Joe", "Bob", "7898675309", "369 Test Street");
		Contact contact2 = new Contact("1", "Joe", "Bob", "7898675309", "369 Test Street");
		service.addContact(contact1);
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.addContact(contact2);
		});
		
	}
	@Test
	//tests if contacts can be deleted
	void testDeleteContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact("1", "Joe", "Bob", "7898675309", "369 Test Street");
		
		service.addContact(contact);
		service.deleteContact("1");
		
		Contact result = service.getContact("1");
		assertNull(result);
		
	}
	@Test
	//tests if first name can be updated successfully
	void testUpdateFirstName() {
		ContactService service = new ContactService();
		Contact contact = new Contact("1", "Joe", "Bob", "7898675309", "369 Test Street");
		
		service.addContact(contact);
		service.updateFirstName("1","Billy");
		
		Contact result = service.getContact("1");
		assertEquals("Billy", result.getFirstName());
		
	}
	@Test
	//tests if phone number can be updated
	void testUpdatePhoneNumber() {
		ContactService service = new ContactService();
		Contact contact = new Contact("1", "Joe", "Bob", "7898675309", "369 Test Street");
		
		service.addContact(contact);
		service.updatePhoneNumber("1","1236547895");
		
		Contact result = service.getContact("1");
		assertEquals("1236547895", result.getPhoneNumber());
		
	}
	@Test
	//tests if phone number is updated with invalid phone number is rejected
	void testUpdateInvalidPhoneNumber() {
        ContactService service = new ContactService();
		
		Contact contact = new Contact("1", "Joe", "Bob", "7898675309", "369 Test Street");
		service.addContact(contact);
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.updatePhoneNumber("1", "50");
		});
	}
    @Test
    //tests if updating contact that doesnt exist throws an error
    void testUpdateContactThatDoesNotExist() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("99", "Bob");
        });
    }
}
