package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {
	
	@Test
	//test contact creation
	void testCreateContact() {
		Contact contact new Contact("1", "Joe", "Bob", "7898675309", "369 Test Street");
		assertEquals("1",contact.getContactID);
		assertEquals("Joe",contact.getFirstName);
		assertEquals("Bob",contact.getLastName);
		assertEquals("7898675309",contact.getPhoneNumber);
		assertEquals("369 Test Street",contact.getAddress);
	}
	
	@Test
	//test rejection of null first name
	void testNullFirstName() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", null, "Bob", "7898675309", "369 Test Street");
		});
		
	}
	@Test
	//test rejection of null last name
	void testNullLastName() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Joe", null, "7898675309", "369 Test Street");
		});
		
	}
	@Test
	//test rejection of contact id if too long
	void testLongContactID() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "Joe", "Bob", "7898675309", "369 Test Street");
		});
		
	}
	@Test
	//test rejection of invalid phone number
	void testPhoneNumInvalid() {

		assertThrows(IllegalArgumentException.class, () -> {

			new Contact("1", "Joe", "Bob", "7898675a", "369 Test Street");

		});
	}
	//test rejection of invalid address
	@Test
	void testAddressIncorrect() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "Joe", "Bob", "7898675309", "36954864513864517451");
		});

}
}
