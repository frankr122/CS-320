package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
	@Test
	//tests adding task
	public void testAddTask() {
		TaskService service = new TaskService();
		Task task = new Task("123", "Test", "Test Desc.");
		service.addTask(task);
		
		assertNotNull(service.getTask("123"));
	}
	//tests deleting task
	@Test
	public void testDeleteTask() {
		TaskService service = new TaskService();
		Task task = new Task("123", "Test", "Test Desc.");
		service.addTask(task);
		
		service.deleteTask("123");
		assertNull(service.getTask("123"));
	}
	//test updating task name
	@Test
	public void testUpdateTaskName() {
		TaskService service = new TaskService();
		Task task = new Task("123", "Test", "Test Desc.");
		service.addTask(task);
		
		service.updateTaskName("123", "NewTest");
		assertEquals("NewTest", service.getTask("123").getName());
	}
	//test updating task description
	@Test
	public void testUpdateTaskDescription() {
		TaskService service = new TaskService();
		Task task = new Task("123", "Test", "Test Desc. New");
		service.addTask(task);
		
		service.updateTaskDescription("123", "Test Desc. New");
		assertEquals("Test Desc. New", service.getTask("123").getDescription());
	}
	//test duplicate ID's
	public void testDuplicateID() {
		public void testUpdateTaskDescription() {
			TaskService service = new TaskService();
			Task task1 = new Task("123", "Test1", "Test Desc1");
			Task task2 = new Task("123", "Test2", "Test Desc2");
			
			service.addTask(task1);
			
			assertThrows(IllegalArgumentException.class, () -> {service.addTask(task2); });	
	}
}
