package task;

import java.util.HashMap;
import java.util.Map;


public class TaskService {
	
	private Map<String, Task> tasks = new HashMap<>();
	
	//Add task
	public void addTask(Task task) {
		if (tasks.containsKey(task.getID())) {
			throw new IllegalArgumentException("Task ID already exists.")
		}
		tasks.put(task.getID(), task);
	}
	//Delete task
	public void deleteTask(String taskID) {
		tasks.remove(taskID);
	}
	//Update task name
	public void updateTaskName(String taskID, String newName) {
		Task task = tasks.get(taskID);
		if (task != null) {
			task.setName(newName);
		}
	}
	//Update task description
	public void updateTaskDescription(String taskID, String newDescription) {
		Task task = tasks.get(taskID);
		if (task != null) {
			task.setDescription(newDescription);
		}
	}
	//testing helper
	public Task getTask(String taskID) { return tasks.get(taskID); }
	}
}
