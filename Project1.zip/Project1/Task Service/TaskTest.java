package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {
	//test task creation
	@Test
	public void testSuccessfulTaskCreation() {
		Task task = new task("98765", "TestTask", "TestTaskDescription");
		assertEquals("98765", task.getID());
		assertEquals("TestTask", task.getName());
		assertEquals("TestTaskDescription", task.getDescription());
	}
	//test id length
	@Test
	public void idTooLong() {
		assertThrows(IllegalArgumentException.class() -> {
			new Task("12345678910", "name","description" );
		});	
	}
	//test name length
	@Test
	public void nameTooLong() {
		assertThrows(IllegalArgumentException.class() -> {
			new Task("123", "namenamenamenamenamenamename","description" );
		});	
	}
	@Test
	public void descriptionTooLong() {
		assertThrows(IllegalArgumentException.class() -> {
			new Task("123", "name","descriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescriptiondescription" );
		});	
	}
	//test setting name
	@Test
	public void testSetName() {
		Task task = new Task("6454", "TestName", "TestDescription");
		task.setName("NewName");
		assertEquals("NewName", task.getName());
	}
	//test setting description
	@Test
	public void testSetDescription() {
		Task task = new Task("6454", "TestName", "TestDescription");
		task.setName("NewDescription");
		assertEquals("NewDescription", task.getDescription());
	}
}
