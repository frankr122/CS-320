package appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

	//Tests successful appointment creation
    @Test
    public void testAppointmentCreatedSuccessfully() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("12345", futureDate, "Doctor visit");

        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor visit", appointment.getDescription());
    }

    //Tests if an appointment id is too long
    @Test
    public void testAppointmentIdTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Checkup");
        });
    }

    //Tests if an appointment date is set to a past date
    @Test
    public void testAppointmentDateInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", pastDate, "Past appointment");
        });
    }

    //Tests if the an appointment description is too long
    @Test
    public void testDescriptionTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate,
                "This description is way too long and exceeds the fifty character limit allowed");
        });
    }

    //Tests setting a new description
    @Test
    public void testSetDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("1", futureDate, "Old");

        appointment.setDescription("New description");
        assertEquals("New description", appointment.getDescription());
    }
}