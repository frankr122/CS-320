package appointment;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    // In-memory storage
    private Map<String, Appointment> appointments = new HashMap<>();

    // Add appointment
    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    // Delete appointment by ID
    public void deleteAppointment(String appointmentId) {
        appointments.remove(appointmentId);
    }

    // Helper method for testing
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
