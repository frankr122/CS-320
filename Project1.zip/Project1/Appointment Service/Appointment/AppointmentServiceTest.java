package appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

	//Tests adding a new appointment
    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("1", futureDate, "Meeting");

        service.addAppointment(appointment);
        assertNotNull(service.getAppointment("1"));
    }

    //Tests deleting an appointment
    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("1", futureDate, "Meeting");

        service.addAppointment(appointment);
        service.deleteAppointment("1");

        assertNull(service.getAppointment("1"));
    }

    //Tests for a duplicate appointment id, throws exception if found
    @Test
    public void testDuplicateAppointmentId() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);

        Appointment appointment1 = new Appointment("1", futureDate, "Meeting");
        Appointment appointment2 = new Appointment("1", futureDate, "Another meeting");

        service.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }
}
